let joinBtn = document.getElementById('join-btn');
let animateInputs = document.querySelectorAll('.animate-input');

let emailAct = nameAct = idAct = pwAct = false;

let userEmail = document.getElementById('userEmail'); 
let userName = document.getElementById('userName'); 
let userId = document.getElementById('userid'); 
let userPw = document.getElementById('userpw');

function updateInputState(input, activeVar) {
  if(input.value.trim().length > 0) {
    input.parentElement.classList.add("active");
    activeVar = true;
  } else {
    input.parentElement.classList.remove("active");
    activeVar = false;
  }
  return activeVar;
}


animateInputs.forEach((item) => {
  let input = item.querySelector('input');

  input.addEventListener('keyup', () => {
    if(input == userEmail) {
      emailAct = updateInputState(input, emailAct);
    } else if (input == userName) {
      nameAct = updateInputState(input, nameAct);
    } else if(input == userId) {
      idAct = updateInputState(input, idAct);
    } else if(input == userPw) {
      pwAct = updateInputState(input, pwAct);
    }

    if(emailAct && nameAct && idAct && pwAct) {
      joinBtn.removeAttribute("disabled");
    } else {
      joinBtn.setAttribute("disabled", true);
    }
  })
});


let pwInput = document.getElementById('user-pw');
let pwBtn = document.getElementById('pw-btn');

function pwToggle() {
  let pwVisible = pwInput.getAttribute("type") === "text";

  pwInput.setAttribute("type", pwVisible ? "password" : "text");
  pwBtn.innerHTML = pwVisible ? "비밀번호 표시" : "숨기기";
}

pwBtn.addEventListener('click', pwToggle);

// Dark | Light Mode Toggle
let modeBtn = document.getElementById("mode-btn");

function modeToggle(e) {
  e.preventDefault();
  let body = document.querySelector("body");
  body.classList.toggle("dark");

  // 삼항연산자
  modeBtn.innerHTML = body.classList.contains("dark") ? `Lightmode` : `Darkmode`;
}
modeBtn.addEventListener('click', modeToggle);
