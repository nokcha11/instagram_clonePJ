package egovframework.com.admin.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import egovframework.com.admin.service.AdminService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("AdminService")
public class AdminServiceImpl extends EgovAbstractServiceImpl implements AdminService{
	
	@Resource(name="AdminDAO")
	private AdminDAO adminDAO;

	@Override
	public int selectIdChk(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.selectIdChk(paramMap);
	}

	@Override
	public int insertAdmin(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.insertAdmin(paramMap);
	}
	
	@Override
	public HashMap<String, Object> selectAdminLoginInfo(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.selectAdminLoginInfo(paramMap);
	}
	
	// 게시판 등록 저장
	@Override
	public int saveEvent(HashMap<String, Object> paramMap, List<MultipartFile> multipartFile) {
		
		int resultChk = 0; //이벤트 저장 결과를 담는 변수
		String flag = paramMap.get("statusFlag").toString(); // flag: 이벤트의 상태(삽입인지 수정인지)를 나타내는 변수로, paramMap에서 가져온다.
		int feedIdx = 0; // 파일 그룹의 시퀀스 번호
		if("I".equals(flag)) {
			resultChk = adminDAO.insertEvent(paramMap);
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+resultChk);
			feedIdx = adminDAO.getFileGroupMaxSeq();
		}else if("U".equals(flag)) {
			resultChk = adminDAO.updateBoard(paramMap);
			feedIdx = adminDAO.getFileGroupSeq(paramMap);
		}
		paramMap.put("feedIdx", feedIdx);
		int chk = 0;
		//파일 저장 경로 및 파일명 설정
		String saveFilePath = "/ictsaeil/insta/";
		String deleteFiles = "";
		if(paramMap.get("deleteFiles") != null ) {
			deleteFiles = (String)paramMap.get("deleteFiles");
		}
		if(deleteFiles.length() >0) {
			// 파일 테이블 데이터 삭제
			adminDAO.deleteFileInfo(paramMap);
		}
		
		if(multipartFile.size() > 0 && !multipartFile.get(0).getOriginalFilename().equals("")) {
			
			int index = 0;
			for(MultipartFile file : multipartFile) {
				
				HashMap<String, Object> uploadFile = new HashMap<String, Object>();
				SimpleDateFormat date = new SimpleDateFormat("yyyyMMddHms");
				Calendar cal = Calendar.getInstance();
				String today = date.format(cal.getTime());
				try {
					
					// 파일 저장 처리
					File fileFolder = new File(saveFilePath);
					if(!fileFolder.exists()) {
						if(fileFolder.mkdirs()) {
							System.out.println("[file.mkdirs] : Success");
						}
					}
					
					// 파일 정보 저장 및 파일 저장
					String fileExt = FilenameUtils.getExtension(file.getOriginalFilename());
					double fileSize = file.getSize();
					File saveFile = new File(saveFilePath, "file_"+today+"_"+index+"."+fileExt);
					uploadFile.put("feedIdx", feedIdx);
					uploadFile.put("originalFileName", file.getOriginalFilename());
					uploadFile.put("saveFileName", "file_"+today+"_"+index+"."+fileExt); 
					uploadFile.put("saveFilePath", saveFilePath);
					uploadFile.put("fileSize", fileSize);
					uploadFile.put("fileExt", fileExt);
					uploadFile.put("userid", paramMap.get("userid"));
					
					adminDAO.insertFileAttr(uploadFile);
					
					file.transferTo(saveFile);
					index++;
				}catch(Exception e) {
					e.printStackTrace();
					return 0; // 저장 실패 콘솔로그에 0이 찍히게 해서 확인
				}
			}
		}
		
		return resultChk;
	}
	
//	//feed 리스트
//   @Override
//   public List<HashMap<String, Object>> selectAdminEventList(HashMap<String, Object> paramMap) {
//      
//      List<HashMap<String, Object>> list = adminDAO.selectAdminEventList(paramMap);
//      // 파일 목록 추가
//      for (int i=0; i< list.size(); i++) {
//         List<HashMap<String, Object>> fileList = null;
//         List<HashMap<String, Object>> commentList = null;
//         HashMap<String, Object> feedMap = list.get(i);
//         int feedIdx = Integer.parseInt(feedMap.get("feedIdx").toString());
//         
//         fileList = adminDAO.selectFileList(feedIdx);
//         
//         commentList = adminDAO.selectBoardReply(feedIdx); //  댓글 가져오기
//
//
//         
//         // 파일 리스트에 전체 경로 추가
//         // 이벤트 해시맵에 파일 목록 추가
//         for (HashMap<String, Object> fileMap : fileList) {
//             String fileName = fileMap.get("saveFileName").toString(); // 파일 이름을 가져옴
//             String fullPath = "C:\\ictsaeil\\insta\\" + fileName; // 전체 경로 구성
//             fileMap.put("fullPath", fullPath); // 전체 경로 추가
//         }
//
//         
//         feedMap.put("fileList", fileList);
//         feedMap.put("commentList", commentList); // 댓글 리스트를 feedMap에 추가
//
//       }
//      
//      
//      System.out.println("파일리스트와 댓글리스트 >>>>>>>>>>>>>>>>>>>>>>>");
//      System.out.println(list);
//
//      
//      return list;
//   }
	
	
	//feed 리스트
	@Override
	public HashMap<String, Object> selectAdminEventList(HashMap<String, Object> paramMap) {
		List<HashMap<String, Object>> list = adminDAO.selectAdminEventList(paramMap);

		for (int i = 0; i < list.size(); i++) {
			HashMap<String, Object> feedMap = list.get(i);
			int feedIdx = Integer.parseInt(feedMap.get("feedIdx").toString());

			List<HashMap<String, Object>> fileList = adminDAO.selectFileList(feedIdx); // 파일 리스트 가져오기
			// 파일 리스트에 전체 경로 추가  
			for (HashMap<String, Object> fileMap : fileList) {
				String fileName = fileMap.get("saveFileName") != null ? fileMap.get("saveFileName").toString() : ""; //파일 이름을 가져옴
				String fullPath = "C:\\ictsaeil\\insta\\" + fileName; //전체 경로 구성
				fileMap.put("fullPath", fullPath); //전체 경로 추가
			}
			feedMap.put("fileList", fileList);

			// 댓글 리스트 가져오기
			List<HashMap<String, Object>> commentList = adminDAO.selectBoardReply(feedIdx);
			feedMap.put("commentList", commentList);
		}

		// 게시물 수의 합산을 추가
        int totalPostCount = list.size(); // 리스트의 크기로 게시물 수 계산
        // 로그인한 사용자의 ID를 가져옵니다.
        String userid = paramMap.get("userid").toString(); // paramMap에서 userId를 가져온다고 가정
        // 로그인한 사용자의 게시물 수 계산
        int totalUserFeedCount = adminDAO.selectUserFeedCount(userid); // userId를 이용해 게시물 수를 계산하는 DAO 메소드 호출
        HashMap<String, Object> resultMap = new HashMap<>();
        resultMap.put("feedList", list);
        resultMap.put("totalPostCount", totalPostCount); // 총 게시물 수 추가
        resultMap.put("totalUserFeedCount", totalUserFeedCount); // 값 추가

        return resultMap; // 수정된 반환값
	}


	@Override
	public int selectAdminEventCnt(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.selectAdminEventCnt(paramMap);
	}

	@Override
	public HashMap<String, Object> getAdminEventInfo(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.getAdminEventInfo(paramMap);
	}

	@Override
	public List<HashMap<String, Object>> selectFileList(int feedIdx) {
		// TODO Auto-generated method stub
		return adminDAO.selectFileList(feedIdx);
	}

	@Override
	public int deleteEventInfo(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.deleteEventInfo(paramMap);
	}
	
	@Override
    public HashMap<String, Object> selectBoardDetail(int feedIdx) {
      // TODO Auto-generated method stub
	      HashMap<String, Object> feedMap = adminDAO.selectBoardDetail(feedIdx);

      // 댓글 리스트 가져오기
      List<HashMap<String, Object>> commentList = adminDAO.selectBoardReply(feedIdx);
      feedMap.put("commentList", commentList);
      return feedMap;
    }

	
	@Override
	public int insertReply(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.insertReply(paramMap);
	}

	@Override
	public int deleteReply(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.deleteBoardReply(paramMap);
	}
	
	// 좋아요 기능 구현
	@Override
	public int insertFeedLike(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		
		int resultChk = 0;
		String type = paramMap.get("likeType").toString();
		
		if("I".equals(type)) {
			resultChk = adminDAO.insertFeedLike(paramMap);
		}else if("U".equals(type)){
			resultChk = adminDAO.updateFeedLike(paramMap);
		}
		return resultChk;
	}
	
	
		// 프로필
		@Override
		   public HashMap<String, Object> selectMemberInfo(HashMap<String, Object> paramMap) {
		      return adminDAO.selectMemberInfo(paramMap);
		   }
		
		@Override
		public int deleteMemberInfo(int userid) {
			// TODO Auto-generated method stub
			return 0;
		}
		/*
		// ★★프로필 이미지 편집 시작
	   @Override
	   public HashMap<String, Object> updateProfileImage(MultipartFile file, int profileIdx, HashMap<String, Object> paramMap) {
	       // 파일 검증 (예: 파일이 비어 있는지, 이미지 파일 형식인지 확인)
	       if (file.isEmpty() || !isImageFile(file)) {
	           throw new IllegalArgumentException("유효한 이미지 파일이 아닙니다.");
	       }
	       
	       // 저장할 경로 설정
	       String uploadDir = "C:/userprofile/";
	       String fileName ="profile_" + profileIdx + "_" + file.getOriginalFilename();
	       
	       try {
	           // 파일을 디렉토리에 저장
	           Path filePath = Paths.get(uploadDir + fileName);
	           System.out.println(">>>>>>>>>>>>>파일 저장 경로: " + filePath.toString());
	           Files.write(filePath, file.getBytes());
	           
	           paramMap.put("fileName", fileName);
	           
	           
	           // 업로드한 파일 경로를 데이터베이스에 저장
	           if(profileIdx == 0) {
	        	   adminDAO.insertProfile(paramMap);
	              // 프로필 값이 없을 때 getProfileIdx 쿼리를 통해 profileIdx 를 따서 넘겨줌
	              profileIdx = adminDAO.getProfileIdx(paramMap);
	              paramMap.put("profileIdx", profileIdx);
	           } else {
	               paramMap.put("profileIdx", profileIdx);
	               adminDAO.updateProfileImage(paramMap);
	           }
	           
	           return paramMap;  // 저장된 파일 경로 반환
	       } catch (IOException e) {
	           throw new RuntimeException("파일 저장 중 오류가 발생했습니다.");
	       }
	   }

	   // 이미지 파일 형식을 확인하는 메서드
	   private boolean isImageFile(MultipartFile file) {
	       // 파일의 확장자를 가져와서 이미지 형식 여부를 확인
	       String contentType = file.getContentType();
	       return contentType != null && (contentType.equals("image/jpeg") || contentType.equals("image/png") || contentType.equals("image/gif"));
	   }
	   // ★★프로필 이미지 편집 끝
	   
	   
	   
	   
	   // 프로필 수정
	   @Override
	   public int updateProfile(HashMap<String, Object> paramMap) {
	      // TODO Auto-generated method stub
	      return adminDAO.updateProfile(paramMap);
	   }

	   // 프로필 상세
	   @Override
	   public HashMap<String, Object> selectProfileInfo(HashMap<String, Object> paramMap) {
	      // TODO Auto-generated method stub
	      return adminDAO.selectProfileInfo(paramMap);
	   }
	*/
	
	

	@Override
	public List<HashMap<String, Object>> selectEventApplyList(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.selectEventApplyList(paramMap);
	}

	@Override
	public int setEventJoinCofirm(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return adminDAO.setEventJoinCofirm(paramMap);
	}
	
	
	
}
