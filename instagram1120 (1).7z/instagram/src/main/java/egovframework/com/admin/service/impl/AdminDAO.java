package egovframework.com.admin.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("AdminDAO")
public class AdminDAO extends EgovAbstractMapper{
	
	public int selectIdChk(HashMap<String, Object> paramMap) {
		return selectOne("selectIdChk", paramMap);
	}
	
	public int insertAdmin(HashMap<String, Object> paramMap) {
		return insert("insertAdmin", paramMap);
	}

	public HashMap<String, Object> selectAdminLoginInfo(HashMap<String, Object> paramMap){
		return selectOne("selectAdminLoginInfo", paramMap);
	}
	
	public int insertEvent(HashMap<String, Object> paramMap) {
		return insert("insertEvent", paramMap);
	}
	
	public int updateBoard(HashMap<String, Object> paramMap) {
		return update("updateBoard", paramMap);
	}
	
	public int getFileGroupMaxSeq() {
		return selectOne("getFileGroupMaxSeq");
	}
	
	public int getFileGroupSeq(HashMap<String, Object> paramMap) {
		return selectOne("getFileGroupSeq", paramMap);
	}
	
	public int insertFileAttr(HashMap<String, Object> paramMap) {
		return insert("insertFileAttr", paramMap);
	}
	
	public List<HashMap<String, Object>> selectAdminEventList(HashMap<String, Object> paramMap){
		return selectList("selectAdminEventList", paramMap);
	}
	
	public int selectAdminEventCnt(HashMap<String, Object> paramMap) {
		return selectOne("selectAdminEventCnt", paramMap);
	}
	
	public HashMap<String, Object> getAdminEventInfo(HashMap<String, Object> paramMap){
		return selectOne("selectAdminEventInfo", paramMap);
	}
	
	public List<HashMap<String, Object>> selectFileList(int feedIdx){
		return selectList("selectFileList", feedIdx);
	}
	
	public int deleteFileInfo(HashMap<String, Object> paramMap) {
		return update("deleteFileInfo", paramMap);
	}
	
	public int deleteEventInfo(HashMap<String, Object> paramMap) {
		return update("deleteEventInfo", paramMap);
	}
	
	public HashMap<String, Object> selectBoardDetail(int feedIdx){
        return selectOne("selectBoardDetail", feedIdx);
	}
	
	public int insertReply(HashMap<String, Object> paramMap) {
		return insert("insertReply", paramMap);
	}
	
	public List<HashMap<String, Object>> selectBoardReply(int feedIdx ){
		return selectList("selectBoardReply", feedIdx);
	}
	
	public int deleteBoardReply(HashMap<String, Object> paramMap) {
		return update("deleteReply", paramMap);
	}
	
	// 좋아요 등록
	public int insertFeedLike(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return insert("insertFeedLike", paramMap);
	}
	// 좋아요 취소
	public int updateFeedLike(HashMap<String, Object> paramMap) {
		// TODO Auto-generated method stub
		return update("updateFeedLike", paramMap);
	}
	
	public List<HashMap<String, Object>> selectEventApplyList(HashMap<String, Object> paramMap){
		return selectList("selectEventApplyList", paramMap);
	}
	
	public int setEventJoinCofirm(HashMap<String, Object> paramMap) {
		return update("setEventJoinCofirm", paramMap);
	}
	
	// 프로필- 마이페이지
	public HashMap<String, Object> selectMemberInfo(HashMap<String, Object> paramMap) {
	      return selectOne("selectMemberInfo", paramMap);
	   }
	
	public int deleteMemberInfo(int userid) {
		return update("deleteMemberInfo", userid);
	}
	
	/*
	// ★★ 프로필 이미지 편집 시작~
    public void updateProfileImage(HashMap<String, Object> paramMap) {
       update("updateProfileImage", paramMap);
   }
    
   public void insertProfile(HashMap<String, Object> paramMap) {
      // TODO Auto-generated method stub
      insert("insertProfile", paramMap);
   }

   public int getProfileIdx(HashMap<String, Object> paramMap) {
      // TODO Auto-generated method stub
      return selectOne("getProfileIdx", paramMap);
   }
   
   

    // 프로필 수정
   public int updateProfile(HashMap<String, Object> paramMap) {
      // TODO Auto-generated method stub
      return update("updateProfile", paramMap);
   }

   // 프로필 상세
   public HashMap<String, Object> selectProfileInfo(HashMap<String, Object> paramMap) {
      // TODO Auto-generated method stub
      return selectOne("selectProfileInfo", paramMap);
   }
   */
   
   // 게시물 수 조회
   public int selectUserFeedCount(String userid) {
       return selectOne("selectUserFeedCount", userid);
	}
   
  

}
