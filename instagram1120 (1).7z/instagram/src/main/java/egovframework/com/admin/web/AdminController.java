package egovframework.com.admin.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.admin.service.AdminService;
import egovframework.com.util.SHA256;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class AdminController {

	@Resource(name="AdminService")
	private AdminService adminService;

	SHA256 sha256 = new SHA256();
	
	@RequestMapping("/admin.do")
	public String admin() {
		return "/admin/adminLogin";
	}

	@RequestMapping("/join.do")
	public String join() {
		return "/admin/adminJoin";
	}

	@RequestMapping("/admin/idChk.do")
	public ModelAndView idChk(@RequestParam HashMap<String, Object> paramMap) {
		ModelAndView mv = new ModelAndView();

		int idChk = 0;
		idChk = adminService.selectIdChk(paramMap);
		mv.addObject("idChk", idChk);
		mv.setViewName("jsonView");
		return mv;
	}

	@RequestMapping("/admin/insertAdmin.do")
	public ModelAndView insertMember(@RequestParam HashMap<String, Object> paramMap) throws Exception{
		ModelAndView mv = new ModelAndView();
		String pwd = paramMap.get("userpw").toString();
		System.out.println(paramMap.toString());
		int resultChk = 0;
		resultChk = adminService.insertAdmin(paramMap);

		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

	@RequestMapping("/admin/loginAction.do")
	public String loginAction(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {

		HashMap<String, Object> loginInfo = null;
		loginInfo = adminService.selectAdminLoginInfo(paramMap);
		if(loginInfo != null) {
			session.setAttribute("loginInfo", loginInfo);
			return "redirect:/admin/eventMngList.do";
		}else {
			return "/admin/adminLogin";
		}
	}
	/*
	// 프로필
	@RequestMapping("/mypage.do")
	public String mypage(HttpServletRequest request, Model model) {
		HashMap<String, Object> loginInfo = null;
		HttpSession session = request.getSession();
		loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		System.out.println("<<<<<<<<<<<<<<<<<<");

		System.out.println(loginInfo);
		if(loginInfo != null) {
			model.addAttribute("loginInfo", loginInfo);
			return "eventMng/mypage";
		}else {
			return "redirect:/login.do";
		}
	}
	*/
	
	@RequestMapping("/member/updateMember.do")
	public ModelAndView updateMember(@RequestParam HashMap<String, Object> paramMap, HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		
		String encryptPwd = null;
		if(paramMap.get("accountPwd") != null && paramMap.get("accountPwd") != "" && paramMap.get("accountPwd") != "undefined") {
			// 입력받은 패스워드
			String pwd = paramMap.get("accountPwd").toString();
			try {
				encryptPwd = sha256.encrypt(pwd).toString();
				paramMap.replace("accountPwd", encryptPwd);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		mv.setViewName("jsonView");
		return mv;
	}
	
	@RequestMapping("/member/getMemberInfo.do")
	public ModelAndView getMemberInfo(@RequestParam HashMap<String, Object> paramMap) {
		ModelAndView mv = new ModelAndView();
		HashMap<String, Object> loginInfo = adminService.selectMemberInfo(paramMap);
		mv.addObject("memberInfo", loginInfo);
		mv.setViewName("jsonView");
		return mv;
	}
	
	@RequestMapping("/member/deleteMember.do")
	public ModelAndView deleteMember(@RequestParam(name="userid") int userid) {
		ModelAndView mv = new ModelAndView();
		
		int resultChk = 0;
		resultChk = adminService.deleteMemberInfo(userid);
		
		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

	@RequestMapping("/logout.do")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.setAttribute("loginInfo", null);
		session.removeAttribute("loginInfo");
		session.invalidate();
		return "redirect:/";
	}

	@RequestMapping("/admin/eventMngList.do")
	public String eventMngList() {
		return "eventMng/eventMngList";
	}

	@RequestMapping("/admin/eventRegist.do")
	public String evetnRegist(@RequestParam HashMap<String, Object> paramMap, ModelMap model, HttpSession session) {
		HashMap<String, Object> loginInfo = null;
		loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		if(loginInfo != null) {
			model.addAttribute("loginInfo", loginInfo);
			model.addAttribute("paramInfo", paramMap);
			return "eventMng/eventMngRegist";
		}else {
			return "redirect:/admin.do";
		}
	}

	// paramMap: 이벤트 정보를 담고 있는 해시맵
	// multipartFile: 파일 목록으로, 업로드된 파일들이 포함
	// session: 로그인 사용자 정보

	// 이벤트 정보: paramMap을 사용하여 이벤트 정보가 첫 번째 테이블(예: event 테이블)에 저장
	// 파일 정보: multipartFile을 사용하여 파일 정보가 두 번째 테이블(예: file 테이블)에 저장

	// 피드 등록
	@RequestMapping("/admin/saveEvent.do")
	public ModelAndView saveEvent(@RequestParam HashMap<String, Object> paramMap, @RequestParam(name="fileList") List<MultipartFile> multipartFile
			, HttpSession session) {
		ModelAndView mv = new ModelAndView();

		int resultChk = 0;

		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		// 세션에서 로그인 정보를 가져와 memberId를 paramMap에 추가
		paramMap.put("userid", sessionInfo.get("userid").toString());
		System.out.println("====================");
		System.out.println(paramMap.toString());
		System.out.println("====================");
		resultChk = adminService.saveEvent(paramMap, multipartFile);
		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

//	// 피드 목록
//	@RequestMapping("/admin/getEventList.do")
//	public ModelAndView getEventList(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
//		ModelAndView mv = new ModelAndView();
//
//		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
//		paramMap.put("userid", sessionInfo.get("userid").toString());
//
//		List<HashMap<String, Object>> list = adminService.selectAdminEventList(paramMap);
//		mv.addObject("list", list);
//		mv.setViewName("jsonView");
//		return mv;
//	}
	
	// 피드 목록
	@RequestMapping("/admin/getEventList.do")
	public ModelAndView getEventList(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {

		ModelAndView mv = new ModelAndView();
		// 세션에서 로그인 정보 가져오기
		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		paramMap.put("userid", sessionInfo.get("userid").toString());
		// 게시물 리스트와 총 게시물 수 가져오기
	    HashMap<String, Object> result = adminService.selectAdminEventList(paramMap);
	    
	    List<HashMap<String, Object>> list = (List<HashMap<String, Object>>) result.get("feedList");
	    int totalPostCount = (Integer) result.get("totalPostCount");
	    int totalUserFeedCount = (Integer) result.get("totalUserFeedCount"); // 추가: 로그인한 사용자 게시물 수 가져오기
	 
	    // 결과를 MV에 추가
		mv.addObject("list", list);
		mv.addObject("totalPostCount", totalPostCount); // 총 게시물 수 추가
		mv.addObject("totalUserFeedCount", totalUserFeedCount); // 값 추가
		mv.setViewName("jsonView");
		return mv;
	}

	// 피드 조회
	@RequestMapping("/admin/getEventInfo.do")
	public String getEventInfo(@RequestParam HashMap<String, Object> paramMap, ModelMap model, HttpSession session) {
		HashMap<String, Object> loginInfo = null;
		loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		if(loginInfo != null) {
			model.addAttribute("loginInfo", loginInfo);
			HashMap<String, Object> eventInfo = adminService.getAdminEventInfo(paramMap);
			model.addAttribute("eventInfo", eventInfo);
			return "eventMng/eventMngDetail";
		}else {
			return "redirect:/admin.do";
		}
	}

	@RequestMapping("/admin/getEventInfoDetail.do")
	public ModelAndView getEventInfoDetail(@RequestParam HashMap<String, Object> paramMap, ModelMap model, HttpSession session) {
		ModelAndView mv = new ModelAndView();

		HashMap<String, Object> eventInfo = adminService.getAdminEventInfo(paramMap);

		mv.addObject("eventInfo", eventInfo);
		mv.setViewName("jsonView");
		return mv;
	}


	// 피드 삭제
	@RequestMapping("/admin/deleteEventInfo.do")
	public ModelAndView deleteEventInfo(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();

		int resultChk = 0;
		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		paramMap.put("userid", sessionInfo.get("userid").toString());
		resultChk = adminService.deleteEventInfo(paramMap);
		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

	// 피드 수정(상세)
	@RequestMapping("/main/getBoardDetail.do")
	public ModelAndView getBoardDetail(@RequestParam(name = "feedIdx") int feedIdx) {
		ModelAndView mv = new ModelAndView();
		HashMap<String, Object> feedInfo = adminService.selectBoardDetail(feedIdx);
		List<HashMap<String, Object>> fileList = adminService.selectFileList(feedIdx);
		mv.addObject("fileList", fileList);
		mv.addObject("feedInfo", feedInfo);
		mv.setViewName("jsonView");
		return mv;
	}

	@RequestMapping("/admin/getApplyList.do")
	public String getApplyList(@RequestParam HashMap<String, Object> paramMap, ModelMap model, HttpSession session) {
		HashMap<String, Object> loginInfo = null;
		loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		if(loginInfo != null) {
			model.addAttribute("loginInfo", loginInfo);
			model.addAttribute("paramMap", paramMap);

			return "eventMng/eventMngJoinList";
		}else {
			return "redirect:/admin.do";
		}
	}


	// 댓글 등록
	@RequestMapping("/admin/saveBoardReply.do")
	public ModelAndView saveBoardReply(
			@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();

		HashMap<String, Object> sessionInfo = (HashMap<String, Object>)session.getAttribute("loginInfo");
		paramMap.put("userid", sessionInfo.get("userid").toString());

		int resultChk = 0;


		resultChk = adminService.insertReply(paramMap);

		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");

		return mv;
	}



	// 댓글 목록은 impl에 저장
	// 댁글 삭제
	@RequestMapping("/feed/deleteBoardReply.do")
	public ModelAndView deleteBoardReply(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		HashMap<String, Object> sessionInfo = (HashMap<String, Object>)session.getAttribute("loginInfo");
		paramMap.put("userid", sessionInfo.get("userid").toString());

		int resultChk = 0;


		resultChk = adminService.deleteReply(paramMap);

		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");

		return mv;
	}

	// 피드 이미지 뷰
	@RequestMapping("/main/feedImgView.do")
	public void feedImgView(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "C:/ictsaeil/insta/";
		String fileName = request.getParameter("fileName").toString();

		File imageFile = new File(path, fileName);

		if (imageFile.exists()) {
			response.setContentType("image/jpeg");
			FileInputStream in = new FileInputStream(imageFile);
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = in.read(buffer)) != -1) {
				response.getOutputStream().write(buffer, 0, bytesRead);
			}
			in.close();
		} else {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
		}
	}   

	// 좋아요 기능 구현
	@RequestMapping("/main/feedLike.do")
	public ModelAndView insertFeedLike(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		int resultChk = 0;

		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		paramMap.put("userid", sessionInfo.get("userid").toString());
		paramMap.put("userIdx", sessionInfo.get("userIdx").toString());

		resultChk = adminService.insertFeedLike(paramMap);

		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

	/*
	// 프로필 디테일
	   @RequestMapping("/main/getProfileInfo.do")
	   public ModelAndView getProfileInfo(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
	      ModelAndView mv = new ModelAndView();
	      HashMap<String, Object> profileInfo = adminService.selectProfileInfo(paramMap);
	      mv.addObject("profileInfo", profileInfo);
	      mv.setViewName("jsonView");
	      return mv;
	   }

	   // 프로필 수정
	   @RequestMapping("/main/updateProfile.do")
	   public ModelAndView saveEvent(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
	      ModelAndView mv = new ModelAndView();
	      int resultChk = 0;

	      HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
	      paramMap.put("userid", sessionInfo.get("userid").toString());

	      resultChk = adminService.updateProfile(paramMap);

	      mv.addObject("resultChk", resultChk);
	      mv.setViewName("jsonView");
	      return mv;
	   }
	   
	// ★★프로필 이미지 수정 컨트롤러 시작~ 
	   @RequestMapping(value = "/main/uploadProfileImage.do", method = RequestMethod.POST)
	   public ModelAndView uploadProfileImage(@RequestParam("profileImage") MultipartFile file, HttpSession session) {
	       ModelAndView mv = new ModelAndView();

	       // 로그인된 사용자 정보 확인
	       HashMap<String, Object> loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
	       if (loginInfo == null) {
	           mv.setViewName("redirect:/login.do");
	           return mv;
	       }

	       int profileIdx = loginInfo.get("profileIdx") != null 
	                        ? Integer.parseInt(loginInfo.get("profileIdx").toString()) 
	                        : 0;

	       // 파일 업로드 서비스 호출
	       HashMap<String, Object> profileMap = adminService.updateProfileImage(file, profileIdx, loginInfo);
	       String profileImagePath = (String) profileMap.get("fileName");

	       if (profileImagePath != null) {
	           // 세션에 프로필 이미지 경로를 추가
	           session.setAttribute("profileImagePath", profileImagePath);
	           loginInfo.put("profileIdx", profileMap.get("profileIdx"));  // 세션 정보 업데이트
	           session.setAttribute("loginInfo", loginInfo);

	           // 성공적으로 업로드된 이미지 경로를 Ajax에 전달
	           mv.addObject("result", "success");
	           mv.addObject("profileImagePath", "C:/userprofile/" + profileImagePath); // 상대 경로로 전달
	       } else {
	           mv.addObject("result", "fail");
	           mv.addObject("message", "파일 업로드에 실패했습니다.");
	       }
	       
	       mv.setViewName("jsonView");
	       return mv;
	   }
	   
	   // 프로필 이미지 미리보기
	   @RequestMapping("/main/profileImgView.do")
	   public void view(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      String path = "D:/userprofile";
	      String fileName = request.getParameter("fileName").toString();

	      File imageFile = new File(path, fileName);

	      if (imageFile.exists()) {
	         response.setContentType("image/jpeg");
	         FileInputStream in = new FileInputStream(imageFile);
	         byte[] buffer = new byte[1024];
	         int bytesRead;
	         while ((bytesRead = in.read(buffer)) != -1) {
	            response.getOutputStream().write(buffer, 0, bytesRead);
	         }
	         in.close();
	      } else {
	         response.sendError(HttpServletResponse.SC_NOT_FOUND);
	      }
	   }
	   */
	   
	    
	   













	/*
	 * @RequestMapping("/admin/getFileList.do") public ModelAndView
	 * getFileList(@RequestParam HashMap<String, Object> paramMap) { ModelAndView mv
	 * = new ModelAndView();
	 * 
	 * List<HashMap<String, Object>> fileList =
	 * adminService.selectFileList(paramMap);
	 * 
	 * mv.addObject("fileList", fileList); mv.setViewName("jsonView"); return mv; }
	 */

	@RequestMapping("/admin/getFileDown.do")
	public void downloadFile(@RequestParam HashMap<String, Object> paramMap, HttpServletResponse response) throws Exception {

		try {
			// fileName 파라미터로 파일명을 가져온다.
			String fileName = paramMap.get("fileName").toString();

			// 파일이 실제 업로드 되어있는(파일이 존재하는) 경로를 지정한다.
			String filePath = paramMap.get("filePath").toString();
			String originalFileName = paramMap.get("originalFileName").toString();

			// 경로와 파일명으로 파일 객체를 생성한다.
			File dFile = new File(filePath, fileName);

			// 파일 길이를 가져온다.
			int fSize = (int) dFile.length();

			// 파일이 존재
			if (fSize > 0) {

				// 파일명을 URLEncoder 하여 attachment, Content-Disposition Header로 설정
				String encodedFilename = "attachment; filename*=" + "UTF-8" + "''" + URLEncoder.encode(originalFileName, "UTF-8").replace("\\+", "\\ ");

				// ContentType 설정
				response.setContentType("application/octet-stream; charset=utf-8");

				// Header 설정
				response.setHeader("Content-Disposition", encodedFilename);

				// ContentLength 설정
				response.setContentLengthLong(fSize);

				BufferedInputStream in = null;
				BufferedOutputStream out = null;

				/* BufferedInputStream
				 * 
                java.io의 가장 기본 파일 입출력 클래스
                입력 스트림(통로)을 생성해줌
                사용법은 간단하지만, 버퍼를 사용하지 않기 때문에 느림
                속도 문제를 해결하기 위해 버퍼를 사용하는 다른 클래스와 같이 쓰는 경우가 많음
				 */
				in = new BufferedInputStream(new FileInputStream(dFile));

				/* BufferedOutputStream
				 * 
                java.io의 가장 기본이 되는 파일 입출력 클래스
                출력 스트림(통로)을 생성해줌
                사용법은 간단하지만, 버퍼를 사용하지 않기 때문에 느림
                속도 문제를 해결하기 위해 버퍼를 사용하는 다른 클래스와 같이 쓰는 경우가 많음
				 */
				out = new BufferedOutputStream(response.getOutputStream());

				try {
					byte[] buffer = new byte[4096];
					int bytesRead = 0;

					/*
                    모두 현재 파일 포인터 위치를 기준으로 함 (파일 포인터 앞의 내용은 없는 것처럼 작동)
                    int read() : 1byte씩 내용을 읽어 정수로 반환
                    int read(byte[] b) : 파일 내용을 한번에 모두 읽어서 배열에 저장
                    int read(byte[] b. int off, int len) : 'len'길이만큼만 읽어서 배열의 'off'번째 위치부터 저장
					 */
					while ((bytesRead = in .read(buffer)) != -1) {
						out.write(buffer, 0, bytesRead);
					}

					// 버퍼에 남은 내용이 있다면, 모두 파일에 출력
					out.flush();
				} finally {
					/*
                    현재 열려 in,out 스트림을 닫음
                    메모리 누수를 방지하고 다른 곳에서 리소스 사용이 가능하게 만듬
					 */
					in.close();
					out.close();
				}
			} else {
				throw new FileNotFoundException("파일이 없습니다.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	@RequestMapping("/admin/getEventApplyList.do")
	public ModelAndView getEventApplyList(@RequestParam HashMap<String, Object> paramMap) {
		ModelAndView mv = new ModelAndView();

		List<HashMap<String, Object>> list = adminService.selectEventApplyList(paramMap);
		mv.addObject("list", list);
		mv.setViewName("jsonView");
		return mv;
	}

	@RequestMapping("/admin/setEventApplyConfirm.do")
	public ModelAndView setEventApplyConfirm(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();

		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		paramMap.put("memberId", sessionInfo.get("id").toString());

		int resultChk = 0;

		resultChk = adminService.setEventJoinCofirm(paramMap);

		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

	@RequestMapping("/admin/excelDown.do")
	public void excelDown(@RequestParam HashMap<String, Object> paramMap, HttpServletResponse response) throws Exception {
		Workbook workbook = new SXSSFWorkbook();
		Sheet sheet = workbook.createSheet("접수자 명단");


		int rowIndex = 0;
		Row headerRow = sheet.createRow(rowIndex++);

		Cell headerCell0 = headerRow.createCell(0);
		headerCell0.setCellValue("이름");

		Cell headerCell1 = headerRow.createCell(1);
		headerCell1.setCellValue("성별");

		Cell headerCell2 = headerRow.createCell(2);
		headerCell2.setCellValue("연락처");

		Cell headerCell3 = headerRow.createCell(3);
		headerCell3.setCellValue("이메일");

		Cell headerCell4 = headerRow.createCell(4);
		headerCell4.setCellValue("주소");

		Cell headerCell5 = headerRow.createCell(5);
		headerCell5.setCellValue("당첨여부");


		// bodyRow
		List<HashMap<String, Object>> excelList= adminService.selectEventApplyList(paramMap);
		for(int i=0; i<excelList.size(); i++) {
			Row bodyRow = sheet.createRow(rowIndex++);

			Cell bodyCell1 = bodyRow.createCell(0);
			bodyCell1.setCellValue(excelList.get(i).get("joinName").toString());
			Cell bodyCell2 = bodyRow.createCell(1);
			bodyCell2.setCellValue(excelList.get(i).get("joinSex").toString());
			Cell bodyCell3 = bodyRow.createCell(2);
			bodyCell3.setCellValue(excelList.get(i).get("joinPhone").toString());
			Cell bodyCell4 = bodyRow.createCell(3);
			bodyCell4.setCellValue(excelList.get(i).get("joinEmail").toString());
			Cell bodyCell5 = bodyRow.createCell(4);
			bodyCell5.setCellValue(excelList.get(i).get("joinAddr").toString());
			Cell bodyCell6 = bodyRow.createCell(5);
			bodyCell6.setCellValue(excelList.get(i).get("joinState").toString());
		}

		// 응답 설정	
		response.setContentType("ms-vnd/excel");
		response.setHeader("Content-Disposition", "attachment;filename=applyList.xls");

		workbook.write(response.getOutputStream());
		workbook.close();;

	}


}
