package egovframework.com.admin.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public interface AdminService {
	
	public int selectIdChk(HashMap<String, Object> paramMap);
	
	public int insertAdmin(HashMap<String, Object> paramMap);
	
	HashMap<String, Object> selectAdminLoginInfo(HashMap<String, Object> paramMap);
	
	int saveEvent(HashMap<String, Object> paramMap, List<MultipartFile> multipartFile);
	
	//List<HashMap<String, Object>> selectAdminEventList(HashMap<String, Object> paramMap);
	
	HashMap<String, Object> selectAdminEventList(HashMap<String, Object> paramMap);
	
	int selectAdminEventCnt(HashMap<String, Object> paramMap);
	
	HashMap<String, Object> getAdminEventInfo(HashMap<String, Object> paramMap);
	
	List<HashMap<String, Object>> selectFileList(int feedIdx);
	
	int deleteEventInfo(HashMap<String, Object> paramMap);
	
	public HashMap<String, Object> selectBoardDetail(int feedIdx);
	
	public int insertReply(HashMap<String, Object> paramMap);
	
	public int deleteReply(HashMap<String, Object> paramMap);

	// like 입력
		public int insertFeedLike(HashMap<String, Object> paramMap);
	
	List<HashMap<String, Object>> selectEventApplyList(HashMap<String, Object> paramMap);
	
	int setEventJoinCofirm(HashMap<String, Object> paramMap);

	// 프로필
	public HashMap<String, Object> selectMemberInfo(HashMap<String, Object> paramMap);
	
	public int deleteMemberInfo(int userid);
	
	/*
	// ★★프로필 이미지 수정 시작
    public HashMap<String, Object> updateProfileImage(MultipartFile file, int profileIdx, HashMap<String, Object> paramMap);
   
    // 프로필 수정
    public int updateProfile(HashMap<String, Object> paramMap);

    // 프로필 상세
    public HashMap<String, Object> selectProfileInfo(HashMap<String, Object> paramMap);
	*/

}
