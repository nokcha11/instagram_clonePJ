package egovframework.com.mypage.service.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import egovframework.com.admin.service.impl.AdminDAO;
import egovframework.com.mypage.service.mypageService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("mypageService")

public class mypageServiceImpl  extends EgovAbstractServiceImpl implements mypageService{

	@Resource(name="mypageDAO")
	private mypageDAO mypageDAO;
	
	/*
	// 프로필
	@Override
	   public HashMap<String, Object> selectMemberInfo(HashMap<String, Object> paramMap) {
	      return mypageDAO.selectMemberInfo(paramMap);
	   }
	
	@Override
	public int deleteMemberInfo(int userid) {
		// TODO Auto-generated method stub
		return 0;
	}
	*/

	// ★★프로필 이미지 편집 시작
   @Override
   public HashMap<String, Object> updateProfileImage(MultipartFile file, int profileIdx, HashMap<String, Object> paramMap) {
       // 파일 검증 (예: 파일이 비어 있는지, 이미지 파일 형식인지 확인)
       if (file.isEmpty() || !isImageFile(file)) {
           throw new IllegalArgumentException("유효한 이미지 파일이 아닙니다.");
       }
       
       // 저장할 경로 설정
       String uploadDir = "C:/userprofile/";
       String fileName ="profile_" + profileIdx + "_" + file.getOriginalFilename();
       
       try {
           // 파일을 디렉토리에 저장
           Path filePath = Paths.get(uploadDir + fileName);
           System.out.println(">>>>>>>>>>>>>파일 저장 경로: " + filePath.toString());
           Files.write(filePath, file.getBytes());
           
           paramMap.put("fileName", fileName);
           
           
           // 업로드한 파일 경로를 데이터베이스에 저장
           if(profileIdx == 0) {
        	   mypageDAO.insertProfile(paramMap);
              // 프로필 값이 없을 때 getProfileIdx 쿼리를 통해 profileIdx 를 따서 넘겨줌
              profileIdx = mypageDAO.getProfileIdx(paramMap);
              paramMap.put("profileIdx", profileIdx);
           } else {
               paramMap.put("profileIdx", profileIdx);
               mypageDAO.updateProfileImage(paramMap);
           }
           
           return paramMap;  // 저장된 파일 경로 반환
       } catch (IOException e) {
           throw new RuntimeException("파일 저장 중 오류가 발생했습니다.");
       }
   }

   // 이미지 파일 형식을 확인하는 메서드
   private boolean isImageFile(MultipartFile file) {
       // 파일의 확장자를 가져와서 이미지 형식 여부를 확인
       String contentType = file.getContentType();
       return contentType != null && (contentType.equals("image/jpeg") || contentType.equals("image/png") || contentType.equals("image/gif"));
   }
   // ★★프로필 이미지 편집 끝
   
   
   
   
   // 프로필 수정
   @Override
   public int updateProfile(HashMap<String, Object> paramMap) {
      // TODO Auto-generated method stub
      return mypageDAO.updateProfile(paramMap);
   }

   // 프로필 상세
   @Override
   public HashMap<String, Object> selectProfileInfo(HashMap<String, Object> paramMap) {
      // TODO Auto-generated method stub
      return mypageDAO.selectProfileInfo(paramMap);
   }


	
}
