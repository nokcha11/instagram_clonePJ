package egovframework.com.mypage.service.impl;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractMapper;

@Repository("mypageDAO")
public class mypageDAO extends EgovAbstractMapper{

		/*
	   // 프로필- 마이페이지
		public HashMap<String, Object> selectMemberInfo(HashMap<String, Object> paramMap) {
		      return selectOne("selectMemberInfo", paramMap);
		   }
		
		public int deleteMemberInfo(int userid) {
			return update("deleteMemberInfo", userid);
		}
		*/
		
		// ★★ 프로필 이미지 편집 시작~
	    public void updateProfileImage(HashMap<String, Object> paramMap) {
	       update("updateProfileImage", paramMap);
	   }
	    
	   public void insertProfile(HashMap<String, Object> paramMap) {
	      // TODO Auto-generated method stub
	      insert("insertProfile", paramMap);
	   }

	   public int getProfileIdx(HashMap<String, Object> paramMap) {
	      // TODO Auto-generated method stub
	      return selectOne("getProfileIdx", paramMap);
	   }
	   
	   

	    // 프로필 수정
	   public int updateProfile(HashMap<String, Object> paramMap) {
	      // TODO Auto-generated method stub
	      return update("updateProfile", paramMap);
	   }

	   // 프로필 상세
	   public HashMap<String, Object> selectProfileInfo(HashMap<String, Object> paramMap) {
	      // TODO Auto-generated method stub
	      return selectOne("selectProfileInfo", paramMap);
	   }
	
	
}
