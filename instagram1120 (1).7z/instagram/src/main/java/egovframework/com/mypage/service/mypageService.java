package egovframework.com.mypage.service;

import java.util.HashMap;

import org.springframework.web.multipart.MultipartFile;

public interface mypageService {

	
	/*
	// 프로필 
	public HashMap<String, Object> selectMemberInfo(HashMap<String, Object> paramMap);

	public int deleteMemberInfo(int userid);
	*/

	// ★★프로필 이미지 수정 시작
	public HashMap<String, Object> updateProfileImage(MultipartFile file, int profileIdx, HashMap<String, Object> paramMap);

	// 프로필 수정
	public int updateProfile(HashMap<String, Object> paramMap);

	// 프로필 상세
	public HashMap<String, Object> selectProfileInfo(HashMap<String, Object> paramMap);
	
}
