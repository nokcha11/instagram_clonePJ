package egovframework.com.mypage.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import egovframework.com.admin.service.AdminService;
import egovframework.com.mypage.service.mypageService;

@Controller
public class mypageController {

	@Resource(name="mypageService")
	private mypageService mypageService;
	
	// 프로필
		@RequestMapping("/mypage.do")
		public String mypage(HttpSession session, Model model) {
			
			HashMap<String, Object> loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
			
			System.out.println("<<<<<<<<<<<<<<<<<<");
			
			System.out.println(loginInfo);
			// 로그인 정보가 존재하는지 확인
			if(loginInfo != null) {
				// 로그인 정보가 있을 경우, 필요한 데이터를 모델에 추가
				model.addAttribute("loginInfo", loginInfo);
				return "eventMng/mypage"; // jsp주소
			}else {
				return "redirect:/login.do";
			}
		}
	
	// 프로필 디테일
	@RequestMapping("/main/getProfileInfo.do")
	public ModelAndView getProfileInfo(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		HashMap<String, Object> profileInfo = mypageService.selectProfileInfo(paramMap);
		mv.addObject("profileInfo", profileInfo);
		mv.setViewName("jsonView");
		return mv;
	}

	// 프로필 수정
	@RequestMapping("/main/updateProfile.do")
	public ModelAndView saveEvent(@RequestParam HashMap<String, Object> paramMap, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		int resultChk = 0;

		HashMap<String, Object> sessionInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		paramMap.put("userid", sessionInfo.get("userid").toString());

		resultChk = mypageService.updateProfile(paramMap);

		mv.addObject("resultChk", resultChk);
		mv.setViewName("jsonView");
		return mv;
	}

	// ★★프로필 이미지 수정 컨트롤러 시작~ 
	@RequestMapping(value = "/main/uploadProfileImage.do", method = RequestMethod.POST)
	public ModelAndView uploadProfileImage(@RequestParam("profileImage") MultipartFile file, HttpSession session) {
		ModelAndView mv = new ModelAndView();

		// 로그인된 사용자 정보 확인
		HashMap<String, Object> loginInfo = (HashMap<String, Object>) session.getAttribute("loginInfo");
		if (loginInfo == null) {
			mv.setViewName("redirect:/login.do");
			return mv;
		}

		int profileIdx = loginInfo.get("profileIdx") != null 
				? Integer.parseInt(loginInfo.get("profileIdx").toString()) 
						: 0;

				// 파일 업로드 서비스 호출
				HashMap<String, Object> profileMap = mypageService.updateProfileImage(file, profileIdx, loginInfo);
				String profileImagePath = (String) profileMap.get("fileName");

				if (profileImagePath != null) {
					// 세션에 프로필 이미지 경로를 추가
					session.setAttribute("profileImagePath", profileImagePath);
					loginInfo.put("profileIdx", profileMap.get("profileIdx"));  // 세션 정보 업데이트
					session.setAttribute("loginInfo", loginInfo);

					// 성공적으로 업로드된 이미지 경로를 Ajax에 전달
					mv.addObject("result", "success");
					mv.addObject("profileImagePath", "C:/userprofile/" + profileImagePath); // 상대 경로로 전달
				} else {
					mv.addObject("result", "fail");
					mv.addObject("message", "파일 업로드에 실패했습니다.");
				}

				mv.setViewName("jsonView");
				return mv;
	}
	
	// 프로필 이미지 미리보기
	@RequestMapping("/main/profileImgView.do")
	public void view(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "C:/userprofile";
		String fileName = request.getParameter("fileName").toString();

		File imageFile = new File(path, fileName);

		if (imageFile.exists()) {
			response.setContentType("image/jpeg");
			FileInputStream in = new FileInputStream(imageFile);
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = in.read(buffer)) != -1) {
				response.getOutputStream().write(buffer, 0, bytesRead);
			}
			in.close();
		} else {
			response.sendError(HttpServletResponse.SC_NOT_FOUND);
		}
	}
	
	


}
